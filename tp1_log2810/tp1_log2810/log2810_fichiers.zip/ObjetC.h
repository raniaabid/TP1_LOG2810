//
//  ObjetC.h
//  tp1log2810
//
//  Created by Rania Abid on 2019-10-11.
//  Copyright © 2019 Rania Abid. All rights reserved.
//

#ifndef ObjetC_h
#define ObjetC_h
#include "Objets.h"
class ObjetC :public Objets
{
public:
	ObjetC();

private:

	double poids_ = 6;

};


#endif /* ObjetC_h */
