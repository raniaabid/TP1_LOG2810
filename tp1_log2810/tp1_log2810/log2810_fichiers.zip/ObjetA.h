//
//  ObjetA.h
//  tp1log2810
//
//  Created by Rania Abid on 2019-10-11.
//  Copyright © 2019 Rania Abid. All rights reserved.
//

#ifndef ObjetA_h
#define ObjetA_h
#include "Objets.h"
class ObjetA :public Objets
{
public:
	ObjetA();
private:
	double poids_ = 1;

};

#endif /* ObjetA_h */
