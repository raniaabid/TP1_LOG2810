//
//  RobotZ.cpp
//  tp1log2810
//
//  Created by Rania Abid on 2019-10-29.
//  Copyright © 2019 Rania Abid. All rights reserved.
//

#include <stdio.h>
#include "RobotZ.h"

RobotZ::RobotZ() :Robots() {

}
bool RobotZ::eligible()
{
	return(commande_.getMasseTotale() < 25);
}
double RobotZ::calculerkz()
{
	return (2, 5 + (0, 2 * commande_.getMasseTotale()));
}

double RobotZ::calculerT()
{
	if (eligible())
		return 1;
	return 1;
}
