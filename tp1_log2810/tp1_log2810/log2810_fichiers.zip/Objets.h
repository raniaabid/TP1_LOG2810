//
//  Objets.h
//  tp1log2810
//
//  Created by Rania Abid on 2019-11-05.
//  Copyright © 2019 Rania Abid. All rights reserved.
//

#ifndef Objets_h
#define Objets_h
class Objets {

public:

	Objets();
	double getPoids();
	int getNbObjet();
	void setNbObjet(int n);


protected:

	double poids_;
	int nbObjetB;
};
#endif /* Objets_h */
