//
//  Robots.cpp
//  tp1log2810
//
//  Created by Rania Abid on 2019-11-05.
//  Copyright © 2019 Rania Abid. All rights reserved.
//

#include <stdio.h>
#include "Robots.h"

Robots::Robots()
{
	commande_ = Commande();
}

