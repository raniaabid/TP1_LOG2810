//
//  ObjetB.h
//  tp1log2810
//
//  Created by Rania Abid on 2019-10-11.
//  Copyright © 2019 Rania Abid. All rights reserved.
//

#ifndef ObjetB_h
#define ObjetB_h
#include "Objets.h"

class ObjetB :public Objets
{
public:
	ObjetB();



private:

	double poids_ = 3;


};

#endif /* ObjetB_h */
